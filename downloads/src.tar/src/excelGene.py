'''
Try to generate the excel needed by the project
'''
import glob
import os
from skimage import io
import numpy as np
# from read_nc import readNC
import openpyxl
import geopandas as gpd
from matplotlib.path import Path
import rasterio
from rasterio import transform
from rasterio.mask import mask

mangu = [100.5, 13.7]
huzhiming = [107, 11]
henei = [105.8, 21.1]
yajiada = [106.5, -6]
jilongpo = [101.5, 3]
xinshan = [103.5, 1.5]
cities = [mangu, huzhiming, henei, yajiada, jilongpo, xinshan]

countries = ["THA", "MMR", "VNM", "MYS", "IDN"]

def is_inside(sf, point_x, point_y):
    shapes = sf.shapes()
    records = sf.records()

    for shape, record in zip(shapes, records):
        path = Path(shape.points)
        yn_inside = path.contains_point((point_x, point_y))
    return yn_inside

def readNC(filename, gas_name):
    vcd = io.imread(filename)

    if gas_name == 'HCHO':
        vcd = vcd[0:450, 0:600]
    elif gas_name == 'NO2':
        vcd = vcd[0:900, 0:1200]
    elif gas_name == 'O3':
        vcd = vcd[0:450, 0:600]

    lat = np.linspace(-15, 30, np.shape(vcd)[0])
    lon = np.linspace(90, 150, np.shape(vcd)[1])
    return vcd, lat, lon
 
def main():
    # 这个大小写都不重要吗？？？
    # for gas_name in ['HCHO', 'NO2', 'O3']:
    # for gas_name in ['HCHO', 'NO2']:
    for gas_name in ['O3']:
        # Write an excel for each gas folder
        workbook = openpyxl.Workbook()
        sheet = workbook.active
        excel_name = "../../data/"+gas_name+"_data.xlsx"

        if gas_name == "O3":
            title = ["文件名", "东盟平均（单位 DU）", "泰国", "缅甸", "越南", "马来西亚", "印度尼西亚", "曼谷", "胡志明市", "河内", "雅加达", "吉隆坡", "新山市", "控制类型（NOx控制, HCHO控制, 混合控制）" ]
        else:
            title = ["文件名", "东盟平均单位 mole/cm2", "泰国", "缅甸", "越南", "马来西亚", "印度尼西亚", "曼谷", "胡志明市", "河内", "雅加达", "吉隆坡", "新山市" ]
        sheet.append(title)

        files = glob.glob("../../data/"+gas_name+"/*.tiff") 
        for file in files:
            data = []
            print('Reading file', file)
            gas_now, lat, lon = readNC(file, gas_name)
            print(lat)
            print(np.shape(gas_now))

            filename = os.path.splitext(os.path.basename(file))[0]
            data.append(filename)
            data.append(np.nanmean(gas_now))

            print('Processing countries...')
            for country in countries:
                shapefile_path = '../shp/gadm41_' + country + '_0.shp'
                print('Opening shapefile ', shapefile_path)
                country_borders = gpd.read_file(shapefile_path)


                xmin, ymin = lon.min(), lat.min()
                xmax, ymax = lon.max(), lat.max()
                affine = transform.from_bounds(xmin, ymin, xmax, ymax, gas_now.shape[1], gas_now.shape[0]) 
                crs = rasterio.crs.CRS.from_epsg(4326) # 假设使用的是WGS84坐标系统

                vcd_raster = rasterio.io.MemoryFile().open(
                    driver='GTiff',
                    height=gas_now.shape[0],
                    width=gas_now.shape[1],
                    count=1, 
                    dtype=gas_now.dtype,
                    transform=affine,
                    crs=crs)

                vcd_raster.write(gas_now, indexes=1)
                out_img, out_transform = mask(vcd_raster, country_borders.geometry, crop=True)
                out_data = out_img[0]
                vcd_mean = np.mean(out_data[np.isnan(out_data)==False])
                data.append(vcd_mean)

            print('Processing cities...')
            lon, lat = np.meshgrid(lon, lat)
            for city in cities:
                idx = np.where((lon>city[0]-0.5) & (lon<city[0]+0.5) & (lat>city[1]-0.5) & (lat>city[1]+0.5))
                city_gas = np.nanmean(gas_now[idx[0], idx[1]])
                data.append(city_gas)
            
            # Calculate FNR
            if gas_name == "O3":
                file_hcho = file.replace("O3", "HCHO")
                file_no2 = file.replace("O3", "NO2")

                if len(glob.glob(file_hcho))==0 or len(glob.glob(file_no2))==0:
                    data.append('N/A')
                else:
                    gas_hcho, lat, lon = readNC(file_hcho, 'HCHO')
                    gas_no2, lat, lon = readNC(file_no2, 'NO2')
                    print(np.shape(gas_no2), np.shape(gas_hcho))

                    gas_no2 = gas_no2[::2, ::2]

                    fnr = gas_hcho/gas_no2
                    fnr[(fnr<=1)] = 0
                    fnr[(fnr>1) & (fnr<4)] = 1
                    fnr[(fnr>4)] = 2

                    print('Processing fnr...')
                    type1, type2, type3 = np.count_nonzero(fnr==2), np.count_nonzero(fnr==1), np.count_nonzero(fnr==0)
                    type_all = type1 + type2 + type3
                    print(type1, type2, type3)
                    if type_all != 0:
                        control_type = f"{type1/type_all:.2f} {type2/type_all:.2f} {type3/type_all:.2f}"
                        data.append(control_type)
                    else:
                        data.append('N/A')

            sheet.append(data)
        workbook.save(excel_name)

if __name__ == "__main__":
    main()
