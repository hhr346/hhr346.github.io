'''
This program is the main function for the moduel,
which will call the other functions needed
'''
import sys
import datetime
import json
from input_check import input_check
from read_nc import readNC
from high_recog import high_recog
from plot_graph import plot
from pdfGene import pdfGene
import numpy as np

def datetime_offset_by_month(datetime1, n = 1):
    # create a shortcut object for one day
    one_day = datetime.timedelta(days = 1)
    # first use div and mod to determine year cycle
    q, r = divmod(datetime1.month + n, 12)
    # create a datetime2
    # to be the last day of the target month
    datetime2 = datetime.date(datetime1.year + q, r + 1, 1) - one_day

    if (datetime1.month != (datetime1 + one_day).month):
       return datetime2
    if datetime1.day >= datetime2.day:
        return datetime2
    return datetime2.replace(day=datetime1.day)


def main():
    # Initialize the output data
    output_data = {
        "start_time": None,
        "end_time": None,
        "input_data": None,
        "error_info": None,
        "error_status": None
    }

    start_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # Read the requested data in JSON and check if it's valid
    print('Reading the input')
    # input_file, input_data, error_info, error_status = input_check('../tbl/input_data.json', log_file)
    input_file, input_data , error_info, error_status = input_check(sys.argv[1])
    output_data["input_data"] = input_file
    output_data["error_info"] = error_info
    output_data["error_status"] = error_status

    # log_file = open(input_data.outpath + 'record.log', 'a')
    # log_file.write('Execute on %s\n' %start_time)
    output_data["start_time"] = start_time

    if error_status == 1:
        print('ERROR!')
        output_file = open(input_data.outpath + "output_data.json", 'w')
        json.dump(output_data, output_file)
        return 1

    # Read the nc file that's required
    suffix = "../../data/" + input_data.gas + "/" + input_data.satellite + '_' + input_data.gas + '_'
    start = str(input_data.start) + '01'
    start = datetime.datetime.strptime(start, '%Y%m%d').date()
    end = str(input_data.end) + '01'
    end = datetime.datetime.strptime(end, '%Y%m%d').date()
    d = start

    # Do the month averaging
    # a Minor problem when it comes to the averaging
    month_add = 0
    while d <= end:
        filename = suffix + d.strftime('%Y%m') + '.tiff'
        print('Reading file', filename)
        gas_now, lat, lon = readNC(filename)
        # Designate the nan value to zero, must before the divide
        gas_now[np.isnan(gas_now)] = 0
        if input_data.gas == 'HCHO':
            gas_now = gas_now/1e16
        elif input_data.gas == 'NO2':
            gas_now = gas_now/1e15

        if month_add == 0:
            gas_add = gas_now
        else:
            gas_add += gas_now
        d = datetime_offset_by_month(d)
        month_add += 1
    gas = gas_add/month_add

    # Do the recognition for the high area
    print('Do the recognition')
    group_result, group_number, result = high_recog(gas)
    # Plot the graph
    print('Plotting')
    area = [input_data.lon_s, input_data.lon_e, (input_data.lon_e-input_data.lon_s)/5,
            input_data.lat_s, input_data.lat_e, (input_data.lat_e-input_data.lat_s)/5,]

    pic_path, midd = plot(group_result, group_number, gas, lat, lon, area, input_data)
    # pic_path, midd = plot(group_result, group_number, result, lat, lon, area, input_data)
    pdfGene(input_data, pic_path, midd)

    end_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # log_file.write('Finished on %s\n\n' %end_time)
    output_data["end_time"] = end_time

    output_file = open(input_data.outpath + "output_data.json", 'w')
    json.dump(output_data, output_file)
    output_file.close()


if __name__ == '__main__':
    main()
