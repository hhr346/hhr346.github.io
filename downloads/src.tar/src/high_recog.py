import numpy as np
from collections import deque

# Define some parameters
DISTANCE = 2
RATIO = 0.02

def bfs(matrix, i, j, group_num, group_result):
    queue = deque([(i, j)])
    group_result[i][j] = group_num

    while queue:
        x, y = queue.popleft()
        # directions = [(x-1, y), (x+1, y), (x, y-1), (x, y+1)]  # 上下左右四个方向
        directions = []
        for i in range(-DISTANCE, DISTANCE+1):
            for j in range(-DISTANCE, DISTANCE+1):
                if i == 0 and j == 0:
                    pass
                else:
                    directions.extend([(x+i, y+j)])

        for nx, ny in directions:
            if 0 <= nx < np.shape(matrix)[0] and 0 <= ny < np.shape(matrix)[1] and not group_result[nx][ny] and matrix[nx][ny] == 1:
                queue.append((nx, ny))
                group_result[nx][ny] = group_num


def find_groups(matrix):
    # Use the bfs algo to assign the group numbers to each pixel in the matrix
    group_result = np.zeros_like(matrix)
    group_num = 1
    
    for i in range(np.shape(matrix)[0]):
        for j in range(np.shape(matrix)[1]):
            if matrix[i][j] == 1 and not group_result[i][j]:
                # Use the broad first search to assign the numbers in the matrix
                bfs(matrix, i, j, group_num, group_result)
                group_num += 1
    return group_result, group_num


def high_recog(gas):

    # Change the nan to 0
    gas[np.isnan(gas)] = 0

    # Find out the top 1% of the high values
    num_items = int(gas.size * RATIO) 
    flattened_arr = gas.flatten() 
    sorted_indices = np.argsort(flattened_arr)  
    selected_indices = np.unravel_index(sorted_indices[-num_items:], gas.shape)  
    # print(gas[selected_indices])
    # print(gas[selected_indices][0:10])

    result = np.zeros_like(gas) 
    result[selected_indices] = 1  

    group_result, group_number = find_groups(result)
    return group_result, group_number, result
