import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import cartopy.crs as ccrs
import cartopy.feature as cfeature


def cmap_own():
    cmap_value = np.loadtxt('../tbl/colormap_22.txt') 
    cmap = []
    for i in range(cmap_value.shape[0]):
        cmap.append((cmap_value[i, 0], cmap_value[i, 1], cmap_value[i, 2]))
    return matplotlib.colors.LinearSegmentedColormap.from_list('test_cmap', cmap, N=cmap_value.shape[0])


def plotGraph(area):
    lon_s, lon_e, lon_d, lat_s, lat_e, lat_d = area 
    xticks = np.arange(lon_s, lon_e, lon_d)
    yticks = np.arange(lat_s, lat_e, lat_d)

    # fig = plt.figure(figsize=(9, 6))
    fig = plt.figure(figsize=(10, 10*(lat_e-lat_s)/(lon_e-lon_s)), dpi=300)
    ax = plt.axes(projection=ccrs.PlateCarree())

    ax.set_extent([lon_s, lon_e, lat_s, lat_e], crs=ccrs.PlateCarree())
    ax.coastlines(linewidth=0.5)
    ax.add_feature(cfeature.BORDERS)

    grid = ax.gridlines(draw_labels=True, linewidth=0.5, color='gray', alpha=0.5, linestyle='--')
    grid.right_labels = False
    grid.top_labels = False


def plotTiff(area):
    lon_s, lon_e, lon_d, lat_s, lat_e, lat_d = area 
    xticks = np.arange(lon_s, lon_e, lon_d)
    yticks = np.arange(lat_s, lat_e, lat_d)

    fig = plt.figure(figsize=(10, 10*(lat_e-lat_s)/(lon_e-lon_s)))
    ax = plt.axes(projection=ccrs.PlateCarree())

    ax.set_extent([lon_s, lon_e, lat_s, lat_e], crs=ccrs.PlateCarree())
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
    ax.coastlines(linewidth=0.5)
    ax.add_feature(cfeature.BORDERS)

    # grid = ax.gridlines(draw_labels=True, linewidth=0.5, color='gray', alpha=0.5, linestyle='--')
    # grid.right_labels = False
    # grid.top_labels = False


def plotRec(matrix, ax, group_number, lat, lon, MINNUM):
    matrix = np.array(matrix)
    positions = {}
    loc_rect = []
    for i in range(1, group_number):
        positions[i] = np.argwhere(matrix == i)
        if np.shape(positions[i])[0] < MINNUM:
            pass
        else:
            # Find out the location of the rectangle
            min_lat = lat[min(positions[i][:, 0])]
            min_lon = lon[min(positions[i][:, 1])]
            max_lat = lat[max(positions[i][:, 0])]
            max_lon = lon[max(positions[i][:, 1])]
            loc_rect.append([min_lat, min_lon, (max_lat-min_lat), (max_lon-min_lon)])
    
    for loc in loc_rect:
        # print(loc)
        min_lat, min_lon, d_lat, d_lon = loc
        # Plot the red rectangle
        rect = patches.Rectangle((min_lon, min_lat), d_lon, d_lat, linewidth=2, edgecolor='r', facecolor='none')
        ax.add_patch(rect)

        # Output the result to the txt file
        # outputFile(loc)

    middle_point = []
    for loc in loc_rect:
        min_lat, min_lon, d_lat, d_lon = loc
        middle_point.append([round(min_lat + d_lat/2,4), round(min_lon + d_lon/2, 4)])
    return middle_point


def outputFile(loc):
    # Record the location of the high-valued areas
    # Identify and record the names of the districts by using the shapefile
    fn = open('../out/AreaRecord.txt', 'a')
    fn.write('{}, {}, {}, {}'.format(loc[0], loc[1], loc[2], loc[3]))
    fn.write('\n')
    fn.close()


def plot(group_result, group_number, gas, lat, lon, area, input_data):

    if input_data.gas == 'HCHO':
        MINNUM = 100
    elif input_data.gas == 'NO2':
        MINNUM = 400
    elif input_data.gas == 'O3':
        MINNUM = 400

    data = np.ma.masked_invalid(gas)
    # data = np.ma.masked_invalid(gas/1e16)
    # data = np.ma.masked_invalid(group_result)

    globe = [-180, 180, 60, -90, 90, 30]
    asean = [90, 150, 10, -15, 30, 5]

    # Plot the concentration map
    # colormap = matplotlib.cm.get_cmap('jet')
    # Change the colormap to the my own
    plotGraph(area)

    colormap = cmap_own()
    if input_data.gas == 'HCHO':
        plt.pcolormesh(lon, lat, data, cmap=colormap, linewidth=0, rasterized=True, vmin=0, vmax=2, shading='nearest')
    elif input_data.gas == 'NO2':
        # colormap = 'jet'
        plt.pcolormesh(lon, lat, data, cmap=colormap, linewidth=0, rasterized=True, vmin=0, vmax=8, shading='nearest')
    elif input_data.gas == 'O3':
        # colormap = 'jet'
        plt.pcolormesh(lon, lat, data, cmap=colormap, linewidth=0, rasterized=True, vmin=0, vmax=80, shading='nearest')

    # Plot the rectangle of the top area
    plotRec(group_result, plt.gca(), group_number, lat, lon, MINNUM)
    title = input_data.satellite + '_' + input_data.gas + '_' + str(input_data.start) + '-' + str(input_data.end)

    if input_data.gas == 'HCHO':
        cbar = plt.colorbar(ticks=np.linspace(0, 2, 11), shrink=0.75)
        cbar.set_label(input_data.gas + r' VCD ($\times$10$^{16}$ molec/cm$^2$)', labelpad=30, rotation=270, fontsize=15)
    elif input_data.gas == 'NO2':
        cbar = plt.colorbar(ticks=np.linspace(0, 10, 11), shrink=0.75)
        cbar.set_label(input_data.gas + r' VCD ($\times$10$^{15}$ molec/cm$^2$)', labelpad=30, rotation=270, fontsize=15)
    elif input_data.gas == 'O3':
        cbar = plt.colorbar(ticks=np.linspace(0, 100, 11), shrink=0.75)
        cbar.set_label(input_data.gas + r' VCD DU', labelpad=30, rotation=270, fontsize=15)
    cbar.ax.tick_params(labelsize=12)

    plt.title(title, fontsize=16)
    plt.xlabel('\nLongitude', fontsize=15)
    plt.ylabel('Latitude\n\n\n ', fontsize=15)
    plt.tight_layout()
    picpath = input_data.outpath + title + '.png'
    plt.savefig(picpath)
    plt.close()

    plotTiff(area)

    if input_data.gas == 'HCHO':
        plt.pcolormesh(lon, lat, data, cmap=colormap, linewidth=0, rasterized=True, vmin=0, vmax=2, shading='nearest')
    elif input_data.gas == 'NO2':
        plt.pcolormesh(lon, lat, data, cmap=colormap, linewidth=0, rasterized=True, vmin=0, vmax=8, shading='nearest')
    elif input_data.gas == 'O3':
        plt.pcolormesh(lon, lat, data, cmap=colormap, linewidth=0, rasterized=True, vmin=0, vmax=80, shading='nearest')

    # Plot the rectangle of the top area
    midd = plotRec(group_result, plt.gca(), group_number, lat, lon, MINNUM)
    plt.savefig(input_data.outpath + title + '.tiff')

    return picpath, midd
