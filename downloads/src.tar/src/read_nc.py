'''
This program aims to read from the month 
'''

import numpy as np
# import netCDF4
from skimage import io
import geopandas as gpd
import shapely
import shapely.vectorized

def readNC(filename):
    '''
    # Open file
    file = netCDF4.Dataset(filename, 'r')
    # Read the properties
    vcd, lat, lon = np.array(file['vcd']), np.array(file['latitude']), np.array(file['longitude'])
    file.close()
    '''

    # Open file to read
    vcd = io.imread(filename)
    lat = np.linspace(-15, 30, np.shape(vcd)[0])
    lon = np.linspace(90, 150, np.shape(vcd)[1])
    input('The shape of the vcd is: {}'.format(np.shape(vcd)))

    '''
    We need to do operations on the vcd
    First do the mask on China
    Then do the cutting if necessary
    '''
    # Read the region from China
    lon, lat = np.meshgrid(lon, lat)
    world = gpd.read_file('../tbl/countries.shp')
    China = world.loc[world["NAME"].isin(["CHINA"])]
    # China_frame = China['geometry'][:]
    # China_frame = shapely.unary_union(list(China_frame))
    China_frame = shapely.unary_union(China['geometry'])

    # Do the mask
    mask_path = shapely.vectorized.contains(China_frame, lon, lat)
    vcd[mask_path] = np.nan
    # vcd[mask_path] = 0

    # NAN is designated to zero!
    # vcd[np.isnan(vcd)] = 0

    # Do the cutting
    asean = [90, 150, -15, 30]
    lon_s, lon_e, lat_s, lat_e = asean
    index = np.array(np.where((lon>lon_s) & (lon<lon_e) & (lat>lat_s) & (lat<lat_e)))

    # Remember that the np.where will return a two-dimension array, so we need to divide 2
    y_size = int(np.size(np.array(np.where((lon>lon_s) & (lon<lon_e))))/(np.shape(lon)[0]*2))
    x_size = int(np.size(np.array(np.where((lat>lat_s) & (lat<lat_e))))/(np.shape(lat)[1]*2))
    vcd = vcd[index[0, :], index[1, :]]
    lat = lat[index[0, :], index[1, :]]
    lon = lon[index[0, :], index[1, :]]

    vcd = np.resize(vcd, (x_size, y_size))
    lat = np.resize(lat, (x_size, y_size))
    lon = np.resize(lon, (x_size, y_size))
    lat = lat[:, 0]
    lon = lon[0, :]

    # The former test
    # data = np.load('../tbl/no2_2019.npz')
    # vcd, lat, lon = data['no2'], data['lat'], data['lon']

    return vcd, lat, lon
