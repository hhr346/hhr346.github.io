import os
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.rl_config import defaultPageSize
from reportlab.lib.units import inch
from reportlab.platypus import Image

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
pdfmetrics.registerFont(TTFont('SimSun', '../tbl/simsun.ttc'))

PAGE_HEIGHT=defaultPageSize[1]
PAGE_WIDTH=defaultPageSize[0]

def pdfGene(input_data, pic_path, midd):
    print('Generating PDF')
    # 创建一个简单的文档对象
    doc = SimpleDocTemplate(os.path.dirname(pic_path) + '/' + os.path.splitext(os.path.basename(pic_path))[0] + '.pdf', pagesize=letter)

    # 获取样式表
    styles = getSampleStyleSheet()
    bodyStyle = styles["Normal"]
    bodyStyle.fontName = 'SimSun'
    bodyStyle.fontSize = 12
    bodyStyle.leading = 22
    bodyStyle.firstLineIndent = 32
    bodyStyle.bulletType = 1

    titleStyle = styles["Title"]
    titleStyle.fontName = 'SimSun'
    titleStyle.fontSize = 25

    # 构建文档元素列表
    elements = []

    title = "东盟污染气体热点高值遥感监测模块"
    t = Paragraph(title, titleStyle)
    elements.append(t)

    # 添加图片
    img = Image(pic_path, width=6*inch, height=5*inch)
    elements.append(img)
    # 添加一些 Spacer 对象来增加空间
    elements.append(Spacer(1, 12))
    # 添加说明文字

    sate = f"卫星种类：{input_data.satellite}" 
    gas = f"污染物种类：{input_data.gas}"
    period = f"识别日期范围：" + ("{input_data.start}-{input_data.end}" if input_data.start!=input_data.end else f"{input_data.start}")
    lon = f"经度范围：[{input_data.lon_s}, {input_data.lon_e}]"
    lat = f"纬度范围：[{input_data.lat_s}, {input_data.lat_e}]"
    txt = f"如上图所示，根据卫星的浓度分布图，可识别其高值点的分布，并根据高值分布来绘制相应的高值区域的分布，有利于根据气体高值点的分布对区域污染针对性防治给出指导建议。共有{len(midd)}个高值区域，其中心点的[纬度，经度]如下所示："
    for text in [sate, gas, period, lon, lat, txt]:
        p = Paragraph(text, bodyStyle)
        elements.append(p)
    for mid in midd:
        p = Paragraph(str(mid), bodyStyle)
        elements.append(p)

    # 构建 PDF 文档
    doc.build(elements)
