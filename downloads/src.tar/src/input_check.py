'''
This program aims to check if the data in input.json file is valid.
'''
import glob
import json
import datetime
import os

def input_check(json_file):
    json_file = open(json_file, 'r')
    input_file = json.load(json_file)
    # log_file.write('The parameters are as followed\n')
    # log_file.write(str(input_file))
    # log_file.write('\n')

    class request_data():
        def __init__(self) -> None:
            # Initialize the input data
            self.satellite = None
            self.gas = None
            self.start = None
            self.end = None
            self.lat_s = None
            self.lat_e = None
            self.lon_s = None
            self.lon_e = None
            self.outpath = None
    input_data = request_data()
    # Read the satellite and gas
    input_data.satellite = input_file['satellite'] 
    input_data.gas = input_file['gas']

    # Read the time period
    input_data.start = input_file['period']['start']
    input_data.end = input_file['period']['end']
    date_today = datetime.date.today()
    date_today = int(date_today.strftime("%Y%m"))

    # Read the area location
    input_data.lat_s = input_file['area']['lat_s']
    input_data.lat_e = input_file['area']['lat_e']
    input_data.lon_s = input_file['area']['lon_s']
    input_data.lon_e = input_file['area']['lon_e']

    # Read the outpath
    input_data.outpath = input_file['output_path']

    # Error check for the exceptions
    error_status = 1        # Only set to be zero when everything is ok
    if input_data.satellite not in ['GF5', 'DQ1', 'GF5A', 'GF5B']:
        error_info = 'Error in the satellite selection! Only in [GF5, DQ1, GF5A, GF5B]'
    elif input_data.gas not in ['HCHO', 'NO2', 'O3']:
        error_info = 'Error in the gas selection! Only in [HCHO, NO2, O3]'
    elif (input_data.lat_s > input_data.lat_e) or (input_data.lat_s < -15) or (input_data.lat_e > 30):
        error_info = 'Error in the latitude selection! Only in the range of [-15, 30]'
    elif (input_data.lon_s > input_data.lon_e) or (input_data.lon_s < 90) or (input_data.lon_e > 150):
        error_info = 'Error in the longitude selection! Only in the range of [90, 150]'
    else:
        # Check the time range
        # The initial time
        suffix = "../../data/" + input_data.gas + "/" + input_data.satellite + '_' + input_data.gas + '_'
        file_s = glob.glob(suffix + str(input_data.start) + '.tiff')
        file_e = glob.glob(suffix + str(input_data.end) + '.tiff')
        file_end = sorted(glob.glob(suffix + '*.tiff'))
        endtime = os.path.splitext(os.path.basename(file_end[0]))[0].split('_')[-1]
        endtime = endtime[0:4] + '.' + endtime[4:]

        if len(file_s)==0 or len(file_e)==0:
            if input_data.satellite == 'GF5':
                # error_info = 'Error in the time range of GF5! Only in 2020.01-2020.12'
                error_info = 'Error in the time range of GF5!'
            elif input_data.satellite == 'GF5B':
                # error_info = 'Error in the time range of GF5B! Only in 2021.12-' + endtime
                error_info = 'Error in the time range of GF5B!'
            elif input_data.satellite == 'DQ1':
                # error_info = 'Error in the time range of DQ1! Only in 2022.06-' + endtime
                error_info = 'Error in the time range of DQ1!'
            elif input_data.satellite == 'GF5A':
                # error_info = 'Error in the time range of GF5A! Only in 2023.01-' + endtime
                error_info = 'Error in the time range of GF5A!'
        else:
            error_info = 'All parameters are valid'

    if error_info == 'All parameters are valid':
        error_status = 0

    # log_file.write(error_info)
    # log_file.write('\n')
    return input_file, input_data, error_info, error_status
    

if __name__=="__main__":
    input_check('./input_data.json')
