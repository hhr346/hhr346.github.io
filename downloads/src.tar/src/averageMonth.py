'''
Do the average for the nc files
'''
from netCDF4 import Dataset
import datetime
import numpy as np

start = datetime.date(2022, 6, 1)
end = datetime.date(2022, 6, 30)
d = start

while d <= end:
    corr_file = '/satellite/d2/hhr346/DQ1/LEVEL3/DQ1_' + d.strftime("%Y%m%d") + '_global_grid01cf01.nc'
    print('Opening ', corr_file)
    ncfile = Dataset(corr_file, mode='r')
    vcd = np.array(ncfile['vcd'])
    lat = np.array(ncfile['latitude'])
    lon = np.array(ncfile['longitude'])
    ncfile.close()

    if d == start:
        vcdto = np.zeros_like(vcd)
        weightto = np.zeros_like(vcd)

    index = np.asarray(np.where( (~np.isnan(vcd))))
    if np.shape(index)[1]>0:
        vcdto[index[0,:],index[1,:]] = vcdto[index[0,:],index[1,:]] + vcd[index[0,:],index[1,:]]
        weightto[index[0,:],index[1,:]] = weightto[index[0,:], index[1,:]]+1

    d += datetime.timedelta(1)
vcd = vcdto/weightto

f = Dataset('./DQ1_HCHO_202206.nc', 'w')
f.createDimension('latitude', 1800)
f.createDimension('longitude', 3600)

lat_var = f.createVariable('latitude', np.float32, ('latitude'))
lon_var = f.createVariable('longitude', np.float32, ('longitude'))
vcd_var = f.createVariable('vcd', np.float32, ('latitude', 'longitude'))

vcd_var[:] = vcd
lat_var[:] = lat
lon_var[:] = lon
