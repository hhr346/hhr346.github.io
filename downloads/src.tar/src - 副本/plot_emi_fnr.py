import numpy as np
import cmaps
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.colors import ListedColormap
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from cartopy.mpl.ticker import LongitudeFormatter, LatitudeFormatter

def plot_region_data(data, lat, lon, vlim, region, unit, cmap, title, output):
    fig = plt.figure(figsize=(14, 7))
    proj = ccrs.PlateCarree()
    ax = plt.axes(projection=proj)
    ax.set_extent(region, crs=proj)
    ax.add_feature(cfeature.OCEAN, color='white', facecolor='white')

    plt.pcolormesh(lon, lat, data, vmin=vlim[0], vmax=vlim[1],
                         cmap=cmap, transform=proj, shading='auto')

    # ax.coastlines(color='white')
    # ax.add_feature(cfeature.BORDERS, linestyle=':',color='white')

    ax.coastlines()
    ax.add_feature(cfeature.OCEAN, facecolor='white',edgecolor='black', zorder=100)
    ax.add_feature(cfeature.BORDERS, linestyle=':')
    x_extent = np.linspace(region[0], region[1], 5)
    y_extent = np.linspace(region[2], region[3], 5)

    ax.set_xticks(x_extent, crs=ccrs.PlateCarree())  # 添加经纬度
    ax.set_yticks(y_extent, crs=ccrs.PlateCarree())

    lon_formatter = LongitudeFormatter(zero_direction_label=False)
    lat_formatter = LatitudeFormatter()
    ax.xaxis.set_major_formatter(lon_formatter)
    ax.yaxis.set_major_formatter(lat_formatter)

    for size in ax.get_xticklabels():  # 获取x轴上所有坐标，并设置字号
        size.set_fontsize('15')
    for size in ax.get_yticklabels():  # 获取y轴上所有坐标，并设置字号
        size.set_fontsize('15')

    ax.gridlines(crs=ccrs.PlateCarree(), linewidth=0.8, color='gray', linestyle=':')
    ax.set_title(title, fontsize=28, pad=16)

    # Plot the legend of the control type
    # The big frame outside
    rec_width = 6
    rec_lenth = 15
    rect = patches.Rectangle((150-rec_lenth, 30-rec_width), rec_lenth, rec_width, linewidth=1, edgecolor='r', facecolor='w', zorder=100)
    ax.add_patch(rect)
    # The three color blocks
    rec_square = 1
    block_lon = 136.5
    block_lat = 28.1
    rect = patches.Rectangle((block_lon, block_lat), rec_square, rec_square, linewidth=1,  facecolor='#ED5829', zorder=100)
    ax.add_patch(rect)
    rect = patches.Rectangle((block_lon, block_lat-1.5), rec_square, rec_square, linewidth=1, facecolor='#A4CF51', zorder=100)
    ax.add_patch(rect)
    rect = patches.Rectangle((block_lon, block_lat-3), rec_square, rec_square, linewidth=1, facecolor='#5FA3D6', zorder=100)
    ax.add_patch(rect)

    # The text of the color
    text_lon = 138.5
    text_lat = 28.5
    ax.text(text_lon, text_lat, 'NO2 control', fontsize=10, ha='left', va='center', zorder=100)
    ax.text(text_lon, text_lat-1.5, 'NO2/HCHO control', fontsize=10, ha='left', va='center', zorder=100)
    ax.text(text_lon, text_lat-3, 'HCHO control', fontsize=10, ha='left', va='center', zorder=100)

    # Save the graph
    plt.savefig(output, dpi=300, bbox_inches='tight')
    plt.close()

def plot_tiff(data, lat, lon, vlim, region, unit, cmap, title, output):
    fig = plt.figure(figsize=(10, 10*(region[3]-region[2])/(region[1]-region[0])))
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)

    proj = ccrs.PlateCarree()
    ax = plt.axes(projection=proj)
    ax.set_extent(region, crs=proj)
    plt.pcolormesh(lon, lat, data, vmin=vlim[0], vmax=vlim[1],
                         cmap=cmap, transform=proj, shading='auto')

    ax.coastlines()
    ax.add_feature(cfeature.OCEAN, facecolor='white',edgecolor='black', zorder=100)
    ax.add_feature(cfeature.BORDERS, linestyle=':')

    # Save the graph
    plt.savefig(output, dpi=300)
    plt.close()


def plot(input_data, hcho, no2, lon, lat):

    # Designate the fnr values
    fnr = hcho/no2
    fnr[(fnr<=1)] = 0
    fnr[(fnr>1) & (fnr<4)] = 1
    fnr[(fnr>4)] = 2

    # 读取外部的RGB文件
    rgb_values = np.loadtxt('../tbl/WBGYR.txt')
    # 创建自定义颜色映射
    custom_cmap = ListedColormap(rgb_values)

    title = input_data.satellite + '_OCT_' + str(input_data.start) + '-' + str(input_data.end)
    pic_path = input_data.outpath + title + '.png'
    plot_region_data(data=fnr, lat=lat, lon=lon, vlim=[-1, 3],
                     region=[input_data.lon_s, input_data.lon_e, input_data.lat_s, input_data.lat_e],
                     title='EMI HCHO/$\mathregular{NO_2}$ Ozone Control Type\n' + input_data.satellite + ' ' + str(input_data.start) + '-' + str(input_data.end), 
                     unit='', cmap=custom_cmap,
                     output=pic_path)
    plot_tiff(data=fnr, lat=lat, lon=lon, vlim=[-1, 3], 
                     region=[input_data.lon_s, input_data.lon_e, input_data.lat_s, input_data.lat_e],
                     title='EMI HCHO/$\mathregular{NO_2}$ Ozone Control Type\n' + input_data.satellite + ' ' + str(input_data.start) + '-' + str(input_data.end), 
                     unit='', cmap=custom_cmap,
                     output=input_data.outpath + title + '.tiff')
    # print('Finished!')
    return pic_path 

