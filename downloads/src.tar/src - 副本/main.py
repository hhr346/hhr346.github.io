'''
This program is the main function for the moduel,
which will call the other functions needed
'''
import datetime
import json
import sys
from input_check import input_check
from read_nc import readNC
from plot_emi_fnr import plot
from pdfGene import pdfGene
import numpy as np


def datetime_offset_by_month(datetime1, n = 1):
    # create a shortcut object for one day
    one_day = datetime.timedelta(days = 1)
    # first use div and mod to determine year cycle
    q, r = divmod(datetime1.month + n, 12)
    # create a datetime2
    # to be the last day of the target month
    datetime2 = datetime.date(datetime1.year + q, r + 1, 1) - one_day

    if (datetime1.month != (datetime1 + one_day).month):
       return datetime2
    if datetime1.day >= datetime2.day:
        return datetime2
    return datetime2.replace(day=datetime1.day)


def main():
    # Initialize the output data
    output_data = {
        "start_time": None,
        "end_time": None,
        "input_data": None,
        "error_info": None,
        "error_status": None
    }

    # Write to the log file to start
    # log_file = open('../out/record.log', 'a')
    start_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # log_file.write('Execute on %s\n' %start_time)
    output_data["start_time"] = start_time

    # Read the requested data in JSON and check if it's valid
    print('Reading the input')
    # input_file, input_data , error_info, error_status = input_check('../tbl/input_data.json', log_file)
    input_file, input_data , error_info, error_status = input_check(sys.argv[1])

    output_data["input_data"] = input_file
    output_data["error_info"] = error_info
    output_data["error_status"] = error_status

    if error_status == 1:
        print('ERROR!')
        output_file = open(input_data.outpath + "output_data.json", 'w')
        json.dump(output_data, output_file)
        return 1
    
    # Read the nc file that's required
    suffix_hcho = "../../data/HCHO/" + input_data.satellite + '_HCHO_'
    suffix_no2 = "../../data/NO2/" + input_data.satellite + '_NO2_'
    start = str(input_data.start) + '01'
    start = datetime.datetime.strptime(start, '%Y%m%d').date()
    end = str(input_data.end) + '01'
    end = datetime.datetime.strptime(end, '%Y%m%d').date()
    d = start
    
    # Do the month averaging
    # a Minor problem when it comes to the averaging
    month_add = 0
    while d <= end:
        filename = suffix_no2 + d.strftime('%Y%m') + '.tiff'
        print('Reading file', filename)
        no2_now, lat, lon = readNC(filename)
        # Designate the nan value to zero
        no2_now[np.isnan(no2_now)] = 0
        no2_now = no2_now[::2, ::2]
        no2_now = no2_now[:450, :600]

        filename = suffix_hcho + d.strftime('%Y%m') + '.tiff'
        print('Reading file', filename)
        hcho_now, lat, lon = readNC(filename)
        # Designate the nan value to zero
        hcho_now[np.isnan(hcho_now)] = 0

        if month_add == 0:
            hcho_add = hcho_now
            no2_add = no2_now
        else:
            hcho_add += hcho_now
            no2_add += no2_now
        d = datetime_offset_by_month(d)
        month_add += 1
    hcho = hcho_add/month_add
    no2 = no2_add/month_add

    # Plot the graph
    print('Plotting')
    pic_path = plot(input_data, hcho, no2, lon, lat)
    pdfGene(input_data, pic_path)

    # Write to the log file to finish
    end_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    output_data["end_time"] = end_time
    # log_file.write('Finished on %s\n\n' %end_time)
    # log_file.close()

    output_file = open(input_data.outpath + "output_data.json", 'w')
    json.dump(output_data, output_file)
    output_file.close()

if __name__ == '__main__':
    main()
