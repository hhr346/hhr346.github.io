import numpy as np

# 读取RGB文件
with open('./WhiteBlueGreenYellowRed.rgb', 'r') as f:
    lines = f.readlines()

# 解析RGB值
rgb_values = []
for line in lines:
    rgb = line.strip().split()
    r, g, b = map(int, rgb)
    rgb_values.append([r, g, b])

# 将RGB值归一化到0-1范围
rgb_values_normalized = np.array(rgb_values) / 255.0

# 保存归一化后的RGB值到新文件
with open('./WBGYR.txt', 'w') as f:
    for rgb in rgb_values_normalized:
        f.write(f"{rgb[0]} {rgb[1]} {rgb[2]}\n")