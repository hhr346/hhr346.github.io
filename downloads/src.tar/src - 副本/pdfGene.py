import os
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.rl_config import defaultPageSize
from reportlab.lib.units import inch
from reportlab.platypus import Image

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
pdfmetrics.registerFont(TTFont('SimSun', '../tbl/simsun.ttc'))

PAGE_HEIGHT=defaultPageSize[1]
PAGE_WIDTH=defaultPageSize[0]

def pdfGene(input_data, pic_path):
    print('Generating PDF')
    # 创建一个简单的文档对象
    doc = SimpleDocTemplate(os.path.dirname(pic_path) + '/' + os.path.splitext(os.path.basename(pic_path))[0] + '.pdf', pagesize=letter)

    # 获取样式表
    styles = getSampleStyleSheet()
    bodyStyle = styles["Normal"]
    bodyStyle.fontName = 'SimSun'
    bodyStyle.fontSize = 15
    bodyStyle.leading = 22
    bodyStyle.firstLineIndent = 32
    bodyStyle.bulletType = 1

    titleStyle = styles["Title"]
    titleStyle.fontName = 'SimSun'
    titleStyle.fontSize = 25

    # 构建文档元素列表
    elements = []

    title = "东盟臭氧控制类型时空表征模块"
    t = Paragraph(title, titleStyle)
    elements.append(t)

    # 添加图片
    img = Image(pic_path, width=5*inch, height=4*inch)
    elements.append(img)
    # 添加一些 Spacer 对象来增加空间
    elements.append(Spacer(1, 12))
    # 添加说明文字

    sate = f"卫星种类：{input_data.satellite}" 
    period = f"识别日期范围：" + ("{input_data.start}-{input_data.end}" if input_data.start!=input_data.end else f"{input_data.start}")
    lon = f"经度范围：[{input_data.lon_s}, {input_data.lon_e}]"
    lat = f"纬度范围：[{input_data.lat_s}, {input_data.lat_e}]"
    intro = "臭氧前体物的浓度对生成臭氧来说至关重要，同时不同的臭氧控制类型对应不同的防治手段，所以合理区分不同区域的臭氧前体物控制类型对国家和政府制定合理的方案，识别每一个重点区域臭氧前体物敏感类型，即VOCs控制区、NOx控制区以及VOCs和NOx协同控制区，针对每种类型进一步细化为本地污染控制区和联防联控来进行有效控制十分关键。"
    txt = "如上图所示，根据卫星的甲醛和二氧化氮的浓度分布图，可以绘制臭氧控制类型的分布，有利于根据臭氧控制类型的分布对区域的臭氧污染针对性防治给出指导建议。"
    for text in [sate, period, lon, lat, intro, txt]:
        p = Paragraph(text, bodyStyle)
        elements.append(p)

    # 构建 PDF 文档
    doc.build(elements)
