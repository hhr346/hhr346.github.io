import numpy as np
from glob import glob
import xarray as xr
import h5py
import datetime

def datetime_offset_by_month(datetime1, n = 1):
    # create a shortcut object for one day
    one_day = datetime.timedelta(days = 1)
    # first use div and mod to determine year cycle
    q, r = divmod(datetime1.month + n, 12)
    # create a datetime2
    # to be the last day of the target month
    datetime2 = datetime.date(datetime1.year + q, r + 1, 1) - one_day

    if (datetime1.month != (datetime1 + one_day).month):
       return datetime2
    if datetime1.day >= datetime2.day:
        return datetime2
    return datetime2.replace(day=datetime1.day)

def write_file(ncfiles, gas, begin, end):
    for d in range(begin, end):
        if gas == 'hcho':
            time_target = d.strftime("%Y%m%d")
            hchofiles = sorted(glob(ncfiles+time_target + '*'))
            hcho = []
            for f in hchofiles:
                try:
                    print(f)
                    with h5py.File(f, 'r') as fl:
                        hcho.append(fl['hcho'][:, :])
                        lat = fl['lat'][:]
                        lon = fl['lon'][:]
                except Exception as e:
                    print(f, e)
            hcho = np.nanmean(np.array(hcho), axis=0)
            np.savez('hcho' + time_target + '.npz', hcho=hcho, lat=lat, lon=lon)

        elif gas == 'no2':
            no2files = sorted(glob(ncfiles))
            no2 = []
            for f in no2files:
                try:
                    ds = xr.open_dataset(f)
                    tropo_vcd = ds['tropo_vcd'].loc[-15:30, 90:150]
                    no2.append(tropo_vcd.values)
                    print(f)
                    lat, lon = tropo_vcd['lat'].values, tropo_vcd['lon'].values
                except Exception as e:
                    print(f, e)
            no2 = np.nanmean(np.array(no2), axis=0)
            np.savez('no2_2019.npz',no2=no2,lat=lat,lon=lon)

def regrid(data, lat, lon, newlat, newlon):
    da = xr.DataArray(data, {'lat': lat, 'lon': lon})
    newda = da.interp(lon=newlon, lat=newlat)
    newdata = newda.values
    return newdata

def writeFNR():
    data = np.load('../tbl/hcho_2019.npz')
    hcho, new_lat, new_lon = data['hcho'], data['lat'], data['lon']
    data = np.load('../tbl/no2_2019.npz')
    no2, lat, lon = data['no2'], data['lat'], data['lon']
    no2 = regrid(data=no2, lat=lat, lon=lon, newlat=new_lat, newlon=new_lon)
    fnr = hcho/no2
    np.savez('../tbl/fnr_' + '2019' + '.npz', fnr=fnr, lat=new_lat, lon=new_lon)


if __name__== "__main__":
    # begin = datetime(2020, 1, 1)
    # end = datetime(2022, 1, 1)
    # while(begin < end):
    #     write_file('/path/xxx', 'no2', begin, end)
    #     begin = datetime_offset_by_month(begin)

    writeFNR()
